import AMPeopleApp from '../src/components/AMPeopleApp'

export default function Home() {
  return <AMPeopleApp />
}
