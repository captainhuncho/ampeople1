# AM People — Backend API

REST API for the AM People members club. Built with Node.js + Express + PostgreSQL.

---

## Stack

| Layer | Tech |
|---|---|
| Runtime | Node.js 18+ |
| Framework | Express |
| Database | PostgreSQL |
| Auth | JWT + bcrypt |
| Billing | Stripe Subscriptions |
| Email | Nodemailer (Resend recommended) |
| Apple Wallet | passkit-generator |
| Google Wallet | Google Wallet REST API |

---

## API Routes

### Auth
| Method | Route | Description |
|---|---|---|
| POST | `/auth/login` | Member number + PIN → JWT token |
| POST | `/auth/logout` | Invalidate session |
| POST | `/auth/change-pin` | Update PIN (auth required) |

### Members
| Method | Route | Description |
|---|---|---|
| GET | `/members/me` | Get own profile |
| PATCH | `/members/me` | Update profile |
| GET | `/members/me/rsvps` | Get my event RSVPs |

### Events
| Method | Route | Description |
|---|---|---|
| GET | `/events` | All upcoming events + tier access |
| GET | `/events/:id` | Single event detail |
| POST | `/events/:id/rsvp` | RSVP to event |
| DELETE | `/events/:id/rsvp` | Cancel RSVP |

### Applications
| Method | Route | Description |
|---|---|---|
| POST | `/applications` | Submit membership application |
| GET | `/applications/status/:ref` | Check application status |

### Billing
| Method | Route | Description |
|---|---|---|
| GET | `/billing/tiers` | Tier pricing (public) |
| GET | `/billing/subscription` | My subscription status |
| POST | `/billing/checkout` | Create Stripe checkout session |
| POST | `/billing/portal` | Open Stripe customer portal |
| POST | `/billing/webhook` | Stripe webhook handler |

### Wallet
| Method | Route | Description |
|---|---|---|
| GET | `/wallet/apple` | Download .pkpass file |
| GET | `/wallet/google` | Get Google Wallet save URL |

---

## Deploy to Railway

### 1. Create project
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and init
railway login
railway init
```

### 2. Add PostgreSQL
In Railway dashboard → New Service → Database → PostgreSQL.
`DATABASE_URL` is auto-injected.

### 3. Set environment variables
In Railway dashboard → Variables, add all vars from `.env.example`.

### 4. Deploy
```bash
railway up
```

### 5. Run migrations & seed
```bash
railway run npm run db:migrate
railway run npm run db:seed
```

---

## Local Development

```bash
# Install dependencies
npm install

# Copy env file and fill in values
cp .env.example .env

# Run migrations
npm run db:migrate

# Seed sample data (Maxwell Adjavon, AM-00001, PIN: 0001)
npm run db:seed

# Start dev server
npm run dev
```

---

## Tier System

| Tier | Level | Access | Price |
|---|---|---|---|
| Core | 1 | Entry events | $1,200/yr |
| Select | 2 | Most events | $3,600/yr |
| Elite | 3 | All events | $9,600/yr |
| Founding | 4 | All events + exclusive | Awarded only |

Founding tier is never purchased — it is awarded manually by the membership committee.

---

## Apple Wallet Setup

1. Enroll in Apple Developer Program ($99/yr)
2. Create a Pass Type ID in developer.apple.com
3. Generate and download certificates
4. Convert to .pem: `openssl pkcs12 -in Certificates.p12 -out signerCert.pem -clcerts -nokeys`
5. Place in `/certs` folder
6. Set `APPLE_*` env vars

## Google Wallet Setup

1. Enable Google Wallet API in Google Cloud Console
2. Create a service account and download JSON key
3. Apply for Google Wallet API access (merchant agreement)
4. Create an Issuer account and Class
5. Set `GOOGLE_*` env vars

---

## Connecting the Frontend

In `am-people-complete.html`, replace the demo login logic with real API calls:

```javascript
// Login
async function goToPin() {
  const num = memberInput.value.trim();
  // ... (after PIN entry)
  const res = await fetch('https://your-api.railway.app/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ memberNumber: 'AM-' + num, pin: enteredPin })
  });
  const data = await res.json();
  if (data.token) {
    localStorage.setItem('am_token', data.token);
    enterApp();
  }
}
```
