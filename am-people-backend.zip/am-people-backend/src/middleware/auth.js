// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');

async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = header.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Fetch fresh member data
    const { rows } = await pool.query(
      `SELECT m.*, t.slug as tier_slug, t.name as tier_name, t.level as tier_level
       FROM members m
       JOIN tiers t ON m.tier_id = t.id
       WHERE m.id = $1 AND m.is_active = TRUE`,
      [decoded.memberId]
    );

    if (!rows.length) {
      return res.status(401).json({ error: 'Member not found or inactive' });
    }

    req.member = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function requireTier(minLevel) {
  return (req, res, next) => {
    if (!req.member) return res.status(401).json({ error: 'Not authenticated' });
    if (req.member.tier_level < minLevel) {
      return res.status(403).json({
        error: 'Insufficient tier',
        required: minLevel,
        current: req.member.tier_level
      });
    }
    next();
  };
}

module.exports = { requireAuth, requireTier };
