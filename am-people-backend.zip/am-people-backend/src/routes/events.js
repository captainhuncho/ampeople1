// src/routes/events.js
const router = require('express').Router();
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

router.use(requireAuth);

// ── GET /events ──────────────────────────────────────────
// Returns all events with member's access level and RSVP status
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT
         e.*,
         t.slug as min_tier_slug, t.name as min_tier_name, t.level as min_tier_level,
         r.status as my_rsvp_status,
         (SELECT COUNT(*) FROM rsvps rv WHERE rv.event_id = e.id AND rv.status = 'confirmed') as rsvp_count,
         (e.capacity IS NULL OR
           (SELECT COUNT(*) FROM rsvps rv WHERE rv.event_id = e.id AND rv.status = 'confirmed') < e.capacity
         ) as has_space
       FROM events e
       JOIN tiers t ON e.min_tier_id = t.id
       LEFT JOIN rsvps r ON r.event_id = e.id AND r.member_id = $1
       WHERE e.event_date >= CURRENT_DATE
       ORDER BY e.event_date ASC`,
      [req.member.id]
    );

    const memberTierLevel = req.member.tier_level;

    res.json(rows.map(e => ({
      id: e.id,
      slug: e.slug,
      name: e.name,
      description: e.description,
      date: e.event_date,
      time: e.event_time,
      city: e.city,
      venue: e.venue,
      capacity: e.capacity,
      rsvpCount: parseInt(e.rsvp_count),
      hasSpace: e.has_space,
      dressCode: e.dress_code,
      emoji: e.emoji,
      status: e.status,
      isFoundingOnly: e.is_founding_only,
      minTier: { slug: e.min_tier_slug, name: e.min_tier_name, level: e.min_tier_level },
      access: {
        canAccess: memberTierLevel >= e.min_tier_level &&
                   (!e.is_founding_only || req.member.is_founding),
        myRsvp: e.my_rsvp_status || null
      }
    })));
  } catch (err) {
    console.error('Get events error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /events/:id ──────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT e.*, t.slug as min_tier_slug, t.name as min_tier_name, t.level as min_tier_level,
              r.status as my_rsvp_status,
              (SELECT COUNT(*) FROM rsvps rv WHERE rv.event_id = e.id AND rv.status = 'confirmed') as rsvp_count
       FROM events e
       JOIN tiers t ON e.min_tier_id = t.id
       LEFT JOIN rsvps r ON r.event_id = e.id AND r.member_id = $2
       WHERE e.id = $1 OR e.slug = $1`,
      [req.params.id, req.member.id]
    );

    if (!rows.length) return res.status(404).json({ error: 'Event not found' });
    const e = rows[0];

    const canAccess = req.member.tier_level >= e.min_tier_level &&
                      (!e.is_founding_only || req.member.is_founding);

    res.json({
      id: e.id, slug: e.slug, name: e.name, description: e.description,
      date: e.event_date, time: e.event_time, city: e.city, venue: e.venue,
      capacity: e.capacity, rsvpCount: parseInt(e.rsvp_count),
      dressCode: e.dress_code, emoji: e.emoji, status: e.status,
      isFoundingOnly: e.is_founding_only,
      minTier: { slug: e.min_tier_slug, name: e.min_tier_name, level: e.min_tier_level },
      access: { canAccess, myRsvp: e.my_rsvp_status || null }
    });
  } catch (err) {
    console.error('Get event error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /events/:id/rsvp ────────────────────────────────
router.post('/:id/rsvp', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Fetch event
    const { rows: evRows } = await client.query(
      `SELECT e.*, t.level as min_tier_level,
              (SELECT COUNT(*) FROM rsvps r WHERE r.event_id = e.id AND r.status = 'confirmed') as rsvp_count
       FROM events e JOIN tiers t ON e.min_tier_id = t.id WHERE e.id = $1`,
      [req.params.id]
    );
    if (!evRows.length) return res.status(404).json({ error: 'Event not found' });
    const ev = evRows[0];

    // Tier check
    if (req.member.tier_level < ev.min_tier_level) {
      return res.status(403).json({ error: 'Your tier does not have access to this event' });
    }
    if (ev.is_founding_only && !req.member.is_founding) {
      return res.status(403).json({ error: 'This event is for Founding Members only' });
    }
    if (ev.status === 'cancelled') {
      return res.status(400).json({ error: 'This event has been cancelled' });
    }

    // Capacity check
    if (ev.capacity && parseInt(ev.rsvp_count) >= ev.capacity) {
      // Add to waitlist
      await client.query(
        `INSERT INTO rsvps (event_id, member_id, status)
         VALUES ($1, $2, 'waitlisted')
         ON CONFLICT (event_id, member_id) DO UPDATE SET status = 'waitlisted'`,
        [req.params.id, req.member.id]
      );
      await client.query('COMMIT');
      return res.json({ status: 'waitlisted', message: 'Added to waitlist' });
    }

    // Confirm RSVP
    await client.query(
      `INSERT INTO rsvps (event_id, member_id, status)
       VALUES ($1, $2, 'confirmed')
       ON CONFLICT (event_id, member_id) DO UPDATE SET status = 'confirmed', cancelled_at = NULL`,
      [req.params.id, req.member.id]
    );

    await client.query('COMMIT');
    res.json({ status: 'confirmed', message: 'RSVP confirmed' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('RSVP error:', err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// ── DELETE /events/:id/rsvp ──────────────────────────────
router.delete('/:id/rsvp', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `UPDATE rsvps SET status = 'cancelled', cancelled_at = NOW()
       WHERE event_id = $1 AND member_id = $2 AND status = 'confirmed'
       RETURNING id`,
      [req.params.id, req.member.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'No active RSVP found' });
    res.json({ message: 'RSVP cancelled' });
  } catch (err) {
    console.error('Cancel RSVP error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
