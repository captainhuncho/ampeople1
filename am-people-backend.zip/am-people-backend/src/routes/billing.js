// src/routes/billing.js
const router = require('express').Router();
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

let stripe;
try {
  stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
} catch (e) {
  console.warn('Stripe not configured — billing routes disabled');
}

// ── GET /billing/tiers ───────────────────────────────────
// Public: return tier pricing info
router.get('/tiers', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT slug, name, level, annual_fee, is_awarded FROM tiers ORDER BY level`
    );
    res.json(rows.map(t => ({
      slug: t.slug, name: t.name, level: t.level,
      annualFee: t.annual_fee, isAwarded: t.is_awarded
    })));
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// All routes below require auth
router.use(requireAuth);

// ── GET /billing/subscription ────────────────────────────
router.get('/subscription', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT s.*, t.slug as tier_slug, t.name as tier_name
       FROM subscriptions s JOIN tiers t ON s.tier_id = t.id
       WHERE s.member_id = $1 AND s.status = 'active'
       ORDER BY s.created_at DESC LIMIT 1`,
      [req.member.id]
    );
    if (!rows.length) return res.json({ subscription: null });
    const s = rows[0];
    res.json({
      subscription: {
        id: s.id,
        status: s.status,
        tier: { slug: s.tier_slug, name: s.tier_name },
        currentPeriodEnd: s.current_period_end,
        cancelAtPeriodEnd: s.cancel_at_period_end
      }
    });
  } catch (err) {
    console.error('Get subscription error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /billing/checkout ───────────────────────────────
// Create Stripe checkout session for tier upgrade
router.post('/checkout', async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Billing not configured' });

  const { tierSlug } = req.body;
  const priceMap = {
    core:   process.env.STRIPE_PRICE_CORE,
    select: process.env.STRIPE_PRICE_SELECT,
    elite:  process.env.STRIPE_PRICE_ELITE,
  };

  if (!priceMap[tierSlug]) return res.status(400).json({ error: 'Invalid tier' });

  try {
    // Get or create Stripe customer
    let customerId = req.member.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: req.member.email,
        name: `${req.member.first_name} ${req.member.last_name}`,
        metadata: { memberNumber: req.member.member_number }
      });
      customerId = customer.id;
      await pool.query(
        'UPDATE members SET stripe_customer_id = $1 WHERE id = $2',
        [customerId, req.member.id]
      );
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      line_items: [{ price: priceMap[tierSlug], quantity: 1 }],
      success_url: `${process.env.FRONTEND_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/billing/cancel`,
      metadata: { memberId: req.member.id, tierSlug },
    });

    res.json({ checkoutUrl: session.url });
  } catch (err) {
    console.error('Checkout error:', err);
    res.status(500).json({ error: 'Could not create checkout session' });
  }
});

// ── POST /billing/portal ─────────────────────────────────
// Stripe customer portal (manage/cancel subscription)
router.post('/portal', async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Billing not configured' });

  try {
    if (!req.member.stripe_customer_id) {
      return res.status(400).json({ error: 'No active subscription found' });
    }
    const session = await stripe.billingPortal.sessions.create({
      customer: req.member.stripe_customer_id,
      return_url: `${process.env.FRONTEND_URL}/profile`,
    });
    res.json({ portalUrl: session.url });
  } catch (err) {
    console.error('Portal error:', err);
    res.status(500).json({ error: 'Could not open billing portal' });
  }
});

// ── POST /billing/webhook ────────────────────────────────
// Stripe webhook — update subscription status in DB
// Note: Must be raw body, registered BEFORE express.json()
router.post('/webhook', async (req, res) => {
  if (!stripe) return res.status(503).end();

  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).json({ error: `Webhook error: ${err.message}` });
  }

  const sub = event.data.object;

  try {
    switch (event.type) {

      case 'checkout.session.completed': {
        if (sub.mode !== 'subscription') break;
        const { memberId, tierSlug } = sub.metadata;
        const { rows: tierRows } = await pool.query('SELECT id FROM tiers WHERE slug = $1', [tierSlug]);
        if (!tierRows.length) break;
        const tierId = tierRows[0].id;

        // Upsert subscription record
        await pool.query(
          `INSERT INTO subscriptions (member_id, stripe_subscription_id, stripe_customer_id, tier_id, status)
           VALUES ($1, $2, $3, $4, 'active')
           ON CONFLICT (stripe_subscription_id) DO UPDATE SET status = 'active'`,
          [memberId, sub.subscription, sub.customer, tierId]
        );
        // Upgrade member tier
        await pool.query(
          'UPDATE members SET tier_id = $1 WHERE id = $2',
          [tierId, memberId]
        );
        break;
      }

      case 'customer.subscription.updated': {
        const status = sub.status === 'active' ? 'active' : sub.status;
        await pool.query(
          `UPDATE subscriptions SET status = $1, current_period_start = to_timestamp($2),
           current_period_end = to_timestamp($3), cancel_at_period_end = $4
           WHERE stripe_subscription_id = $5`,
          [status, sub.current_period_start, sub.current_period_end, sub.cancel_at_period_end, sub.id]
        );
        break;
      }

      case 'customer.subscription.deleted': {
        await pool.query(
          `UPDATE subscriptions SET status = 'cancelled', cancelled_at = NOW()
           WHERE stripe_subscription_id = $1`,
          [sub.id]
        );
        // Downgrade to Core
        await pool.query(
          `UPDATE members SET tier_id = (SELECT id FROM tiers WHERE slug = 'core')
           WHERE stripe_customer_id = $1 AND is_founding = FALSE`,
          [sub.customer]
        );
        break;
      }
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook processing error:', err);
    res.status(500).end();
  }
});

module.exports = router;
