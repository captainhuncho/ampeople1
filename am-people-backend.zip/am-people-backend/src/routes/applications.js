// src/routes/applications.js
const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const pool = require('../db/pool');
const emailService = require('../services/email');

// Rate limit: 3 applications per hour per IP
const applyLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: { error: 'Too many applications from this IP. Please try again later.' }
});

// ── POST /applications ───────────────────────────────────
router.post('/', applyLimiter, [
  body('firstName').trim().notEmpty().isLength({ max: 100 }),
  body('lastName').trim().notEmpty().isLength({ max: 100 }),
  body('email').trim().isEmail().normalizeEmail(),
  body('homeCity').trim().notEmpty(),
  body('profession').trim().notEmpty().isLength({ max: 150 }),
  body('whyJoin').trim().notEmpty().isLength({ min: 20, max: 1000 }),
  body('preferredTier').isIn(['core', 'select', 'elite']),
  body('phone').optional().trim().isLength({ max: 30 }),
  body('source').optional().trim().isLength({ max: 100 }),
  body('referringMemberNumber').optional().trim()
    .matches(/^AM-\d{4,5}$/).withMessage('Invalid referring member number format'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  const {
    firstName, lastName, email, phone, homeCity, profession,
    source, referringMemberNumber, whyJoin, preferredTier
  } = req.body;

  try {
    // Check for duplicate email
    const { rows: existing } = await pool.query(
      `SELECT id, status FROM applications WHERE email = $1
       UNION SELECT id, 'member' as status FROM members WHERE email = $1`,
      [email]
    );
    if (existing.length) {
      return res.status(409).json({ error: 'An application with this email already exists' });
    }

    // Generate ref number: AM-APP-XXXX
    const refNum = 'AM-APP-' + String(Math.floor(1000 + Math.random() * 9000));

    // Validate referring member if provided
    if (referringMemberNumber) {
      const { rows } = await pool.query(
        'SELECT id FROM members WHERE member_number = $1 AND is_active = TRUE',
        [referringMemberNumber.toUpperCase()]
      );
      if (!rows.length) {
        return res.status(400).json({ error: 'Referring member number not found' });
      }
    }

    await pool.query(
      `INSERT INTO applications
         (ref_number, first_name, last_name, email, phone, home_city, profession,
          source, referring_member_number, why_join, preferred_tier)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [refNum, firstName, lastName, email, phone || null, homeCity, profession,
       source || null, referringMemberNumber?.toUpperCase() || null, whyJoin, preferredTier]
    );

    // Send confirmation email (non-blocking)
    emailService.sendApplicationConfirmation({ firstName, email, refNum }).catch(console.error);

    res.status(201).json({
      message: 'Application received',
      refNumber: refNum
    });
  } catch (err) {
    console.error('Application error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /applications/:ref ───────────────────────────────
// Check application status by ref number
router.get('/status/:ref', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT ref_number, status, first_name, created_at, reviewed_at
       FROM applications WHERE ref_number = $1`,
      [req.params.ref.toUpperCase()]
    );
    if (!rows.length) return res.status(404).json({ error: 'Application not found' });
    const a = rows[0];
    res.json({
      refNumber: a.ref_number,
      status: a.status,
      firstName: a.first_name,
      appliedAt: a.created_at,
      reviewedAt: a.reviewed_at
    });
  } catch (err) {
    console.error('Application status error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
