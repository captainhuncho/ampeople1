// src/routes/members.js
const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// All member routes require auth
router.use(requireAuth);

// ── GET /members/me ──────────────────────────────────────
router.get('/me', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT
        m.id, m.member_number, m.first_name, m.last_name,
        m.email, m.phone, m.home_city, m.profession,
        m.is_founding, m.profile_handle, m.avatar_url,
        m.joined_at, m.last_login,
        t.slug as tier_slug, t.name as tier_name, t.level as tier_level,
        (SELECT COUNT(*) FROM rsvps r WHERE r.member_id = m.id AND r.status = 'confirmed') as events_attended
       FROM members m
       JOIN tiers t ON m.tier_id = t.id
       WHERE m.id = $1`,
      [req.member.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Member not found' });

    const m = rows[0];
    res.json({
      id: m.id,
      memberNumber: m.member_number,
      firstName: m.first_name,
      lastName: m.last_name,
      email: m.email,
      phone: m.phone,
      homeCity: m.home_city,
      profession: m.profession,
      isFounding: m.is_founding,
      profileHandle: m.profile_handle,
      avatarUrl: m.avatar_url,
      joinedAt: m.joined_at,
      lastLogin: m.last_login,
      tier: { slug: m.tier_slug, name: m.tier_name, level: m.tier_level },
      stats: { eventsAttended: parseInt(m.events_attended) }
    });
  } catch (err) {
    console.error('Get member error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── PATCH /members/me ────────────────────────────────────
router.patch('/me', [
  body('firstName').optional().trim().isLength({ min: 1, max: 100 }),
  body('lastName').optional().trim().isLength({ min: 1, max: 100 }),
  body('phone').optional().trim().isLength({ max: 30 }),
  body('homeCity').optional().trim().isLength({ max: 100 }),
  body('profession').optional().trim().isLength({ max: 150 }),
  body('profileHandle').optional().trim().isLength({ min: 3, max: 50 })
    .matches(/^[a-z0-9_]+$/).withMessage('Handle: lowercase letters, numbers, underscores only'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  const allowed = ['firstName','lastName','phone','homeCity','profession','profileHandle'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

  if (!Object.keys(updates).length) return res.status(400).json({ error: 'No valid fields to update' });

  // Map camelCase to snake_case columns
  const colMap = {
    firstName: 'first_name', lastName: 'last_name', phone: 'phone',
    homeCity: 'home_city', profession: 'profession', profileHandle: 'profile_handle'
  };

  const setClauses = Object.keys(updates).map((k, i) => `${colMap[k]} = $${i + 2}`);
  const values = [req.member.id, ...Object.values(updates)];

  try {
    // Check handle uniqueness
    if (updates.profileHandle) {
      const { rows } = await pool.query(
        'SELECT id FROM members WHERE profile_handle = $1 AND id != $2',
        [updates.profileHandle, req.member.id]
      );
      if (rows.length) return res.status(409).json({ error: 'Handle already taken' });
    }

    await pool.query(
      `UPDATE members SET ${setClauses.join(', ')} WHERE id = $1`,
      values
    );
    res.json({ message: 'Profile updated' });
  } catch (err) {
    console.error('Update member error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── GET /members/me/rsvps ────────────────────────────────
router.get('/me/rsvps', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT r.id, r.status, r.rsvp_at,
              e.id as event_id, e.name, e.event_date, e.event_time,
              e.city, e.venue, e.emoji
       FROM rsvps r
       JOIN events e ON r.event_id = e.id
       WHERE r.member_id = $1
       ORDER BY e.event_date DESC`,
      [req.member.id]
    );
    res.json(rows.map(r => ({
      id: r.id, status: r.status, rsvpAt: r.rsvp_at,
      event: { id: r.event_id, name: r.name, date: r.event_date, time: r.event_time, city: r.city, venue: r.venue, emoji: r.emoji }
    })));
  } catch (err) {
    console.error('Get RSVPs error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
