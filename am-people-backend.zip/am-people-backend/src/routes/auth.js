// src/routes/auth.js
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const rateLimit = require('express-rate-limit');
const pool = require('../db/pool');

// Rate limit login: 10 attempts per 15 min per IP
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many login attempts. Try again in 15 minutes.' }
});

// ── POST /auth/login ─────────────────────────────────────
// Body: { memberNumber: "AM-00001", pin: "0001" }
router.post('/login', loginLimiter, [
  body('memberNumber').matches(/^AM-\d{4,5}$/).withMessage('Invalid member number format'),
  body('pin').isLength({ min: 4, max: 4 }).isNumeric().withMessage('PIN must be 4 digits'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: errors.array()[0].msg });
  }

  const { memberNumber, pin } = req.body;

  try {
    const { rows } = await pool.query(
      `SELECT m.*, t.slug as tier_slug, t.name as tier_name, t.level as tier_level
       FROM members m
       JOIN tiers t ON m.tier_id = t.id
       WHERE m.member_number = $1 AND m.is_active = TRUE`,
      [memberNumber.toUpperCase()]
    );

    // Always compare hash to prevent timing attacks
    const member = rows[0];
    const dummyHash = '$2a$12$invalidhashfortimingprotection000000000000000000000000';
    const valid = await bcrypt.compare(pin, member ? member.pin_hash : dummyHash);

    if (!member || !valid) {
      return res.status(401).json({ error: 'Invalid member number or PIN' });
    }

    // Issue JWT
    const token = jwt.sign(
      { memberId: member.id, memberNumber: member.member_number },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    // Update last login
    await pool.query(
      'UPDATE members SET last_login = NOW() WHERE id = $1',
      [member.id]
    );

    res.json({
      token,
      member: {
        id: member.id,
        memberNumber: member.member_number,
        firstName: member.first_name,
        lastName: member.last_name,
        email: member.email,
        tier: { slug: member.tier_slug, name: member.tier_name, level: member.tier_level },
        isFounding: member.is_founding,
        profileHandle: member.profile_handle,
        avatarUrl: member.avatar_url,
        joinedAt: member.joined_at,
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── POST /auth/logout ────────────────────────────────────
router.post('/logout', async (req, res) => {
  // Client drops the token — stateless JWT
  // For session invalidation extend with a token blocklist
  res.json({ message: 'Logged out successfully' });
});

// ── POST /auth/change-pin ────────────────────────────────
const { requireAuth } = require('../middleware/auth');
router.post('/change-pin', requireAuth, [
  body('currentPin').isLength({ min: 4, max: 4 }).isNumeric(),
  body('newPin').isLength({ min: 4, max: 4 }).isNumeric(),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  const { currentPin, newPin } = req.body;

  try {
    const { rows } = await pool.query('SELECT pin_hash FROM members WHERE id = $1', [req.member.id]);
    const valid = await bcrypt.compare(currentPin, rows[0].pin_hash);
    if (!valid) return res.status(401).json({ error: 'Current PIN is incorrect' });

    const newHash = await bcrypt.hash(newPin, 12);
    await pool.query('UPDATE members SET pin_hash = $1 WHERE id = $2', [newHash, req.member.id]);

    res.json({ message: 'PIN updated successfully' });
  } catch (err) {
    console.error('Change PIN error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
