// src/routes/wallet.js
const router = require('express').Router();
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

router.use(requireAuth);

const TIER_COLORS = {
  core:     { bg: '#1a1a14', fg: '#7a9e8a', label: '#ffffff' },
  select:   { bg: '#1a1408', fg: '#b8955a', label: '#ffffff' },
  elite:    { bg: '#141208', fg: '#c0a060', label: '#ffffff' },
  founding: { bg: '#0d0d0b', fg: '#e8cc9a', label: '#ffffff' },
};

// ── GET /wallet/apple ────────────────────────────────────
router.get('/apple', async (req, res) => {
  const certsExist =
    process.env.APPLE_WWDR_CERT &&
    fs.existsSync(process.env.APPLE_WWDR_CERT);

  if (!certsExist) {
    return res.status(503).json({
      error: 'Apple Wallet not configured',
      setup: 'Add Apple Developer certificates to /certs and set env vars. See README.'
    });
  }

  try {
    const { PKPass } = require('passkit-generator');
    const member = req.member;
    const colors = TIER_COLORS[member.tier_slug] || TIER_COLORS.core;
    const serial = uuidv4();

    // Generate QR code data URL
    const qrData = JSON.stringify({
      memberNumber: member.member_number,
      memberId: member.id,
      t: Date.now()
    });

    const pass = await PKPass.from({
      model: path.join(__dirname, '../assets/apple-pass-model'),
      certificates: {
        wwdr: fs.readFileSync(process.env.APPLE_WWDR_CERT),
        signerCert: fs.readFileSync(process.env.APPLE_SIGNER_CERT),
        signerKey: {
          keyFile: fs.readFileSync(process.env.APPLE_SIGNER_KEY),
          passphrase: process.env.APPLE_SIGNER_KEY_PASS
        }
      }
    }, {
      serialNumber: serial,
      description: 'AM People Membership',
      organizationName: 'AM People',
      passTypeIdentifier: process.env.APPLE_PASS_TYPE_ID,
      teamIdentifier: process.env.APPLE_TEAM_ID,
      foregroundColor: colors.label,
      backgroundColor: colors.bg,
      labelColor: colors.fg,
    });

    pass.type = 'generic';
    pass.setLocations();

    pass.primaryFields.push({
      key: 'memberName',
      label: 'MEMBER',
      value: `${member.first_name} ${member.last_name}`
    });
    pass.secondaryFields.push({
      key: 'memberNumber',
      label: 'MEMBER NO.',
      value: member.member_number
    });
    pass.secondaryFields.push({
      key: 'tier',
      label: 'TIER',
      value: member.tier_name.toUpperCase()
    });
    pass.auxiliaryFields.push({
      key: 'since',
      label: 'MEMBER SINCE',
      value: new Date(member.joined_at).getFullYear().toString()
    });
    if (member.is_founding) {
      pass.auxiliaryFields.push({ key: 'founding', label: '', value: '✦ Founding Member' });
    }

    // Store pass record
    await pool.query(
      `INSERT INTO wallet_passes (member_id, platform, pass_serial)
       VALUES ($1, 'apple', $2) ON CONFLICT DO NOTHING`,
      [member.id, serial]
    );

    const buffer = await pass.generate();
    res.setHeader('Content-Type', 'application/vnd.apple.pkpass');
    res.setHeader('Content-Disposition', `attachment; filename="ampeople-${member.member_number}.pkpass"`);
    res.send(buffer);

  } catch (err) {
    console.error('Apple Wallet error:', err);
    res.status(500).json({ error: 'Could not generate pass', detail: err.message });
  }
});

// ── GET /wallet/google ───────────────────────────────────
router.get('/google', async (req, res) => {
  if (!process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL || !process.env.GOOGLE_WALLET_ISSUER_ID) {
    return res.status(503).json({
      error: 'Google Wallet not configured',
      setup: 'Add Google service account credentials and set env vars. See README.'
    });
  }

  try {
    const { GoogleAuth } = require('google-auth-library');
    const jwt = require('jsonwebtoken');
    const member = req.member;
    const colors = TIER_COLORS[member.tier_slug] || TIER_COLORS.core;

    const serviceAccountKey = JSON.parse(
      fs.readFileSync(process.env.GOOGLE_SERVICE_ACCOUNT_KEY, 'utf8')
    );

    const issuerId = process.env.GOOGLE_WALLET_ISSUER_ID;
    const classId = process.env.GOOGLE_WALLET_CLASS_ID;
    const objectId = `${issuerId}.${member.member_number.replace('-', '')}`;

    const passObject = {
      id: objectId,
      classId: `${issuerId}.${classId}`,
      state: 'ACTIVE',
      cardTitle: { defaultValue: { language: 'en', value: 'AM People' } },
      subheader: { defaultValue: { language: 'en', value: 'MEMBERSHIP' } },
      header: { defaultValue: { language: 'en', value: `${member.first_name} ${member.last_name}` } },
      textModulesData: [
        { header: 'MEMBER NO.', body: member.member_number, id: 'memberNumber' },
        { header: 'TIER', body: member.tier_name.toUpperCase(), id: 'tier' },
        { header: 'MEMBER SINCE', body: new Date(member.joined_at).getFullYear().toString(), id: 'since' },
      ],
      barcode: {
        type: 'QR_CODE',
        value: JSON.stringify({ memberNumber: member.member_number, memberId: member.id }),
        alternateText: member.member_number
      },
      hexBackgroundColor: colors.bg,
    };

    // Build JWT for save link
    const claims = {
      iss: serviceAccountKey.client_email,
      aud: 'google',
      origins: [process.env.FRONTEND_URL],
      typ: 'savetowallet',
      payload: { genericObjects: [passObject] }
    };

    const token = jwt.sign(claims, serviceAccountKey.private_key, { algorithm: 'RS256' });
    const saveUrl = `https://pay.google.com/gp/v/save/${token}`;

    // Store pass record
    await pool.query(
      `INSERT INTO wallet_passes (member_id, platform, pass_serial)
       VALUES ($1, 'google', $2) ON CONFLICT DO NOTHING`,
      [member.id, objectId]
    );

    res.json({ saveUrl });

  } catch (err) {
    console.error('Google Wallet error:', err);
    res.status(500).json({ error: 'Could not generate Google Wallet pass', detail: err.message });
  }
});

module.exports = router;
