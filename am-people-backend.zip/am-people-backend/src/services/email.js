// src/services/email.js
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.resend.com',
  port: parseInt(process.env.SMTP_PORT) || 465,
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const FROM = process.env.EMAIL_FROM || 'members@ampeople.co';

// ── Base email template ───────────────────────────────────
function baseTemplate(content) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { margin:0; padding:0; background:#060604; font-family:'Georgia',serif; color:#ede5d0; }
    .wrap { max-width:520px; margin:0 auto; padding:48px 32px; }
    .logo { font-size:20px; letter-spacing:0.4em; color:#b8955a; text-transform:uppercase; margin-bottom:40px; }
    .logo em { font-style:italic; color:rgba(184,149,90,0.5); }
    .divider { border:none; border-top:1px solid rgba(184,149,90,0.15); margin:32px 0; }
    .footer { font-size:11px; letter-spacing:0.15em; color:rgba(237,229,208,0.3);
              text-transform:uppercase; font-family:monospace; margin-top:40px; }
    h1 { font-size:32px; font-weight:300; line-height:1.2; margin:0 0 16px; }
    h1 em { font-style:italic; color:#b8955a; }
    p { font-size:16px; font-weight:300; line-height:1.7; color:rgba(237,229,208,0.7); margin:0 0 16px; }
    .badge { display:inline-block; border:1px solid rgba(184,149,90,0.3); border-radius:30px;
             padding:8px 20px; font-size:12px; letter-spacing:0.2em; color:#b8955a;
             text-transform:uppercase; font-family:monospace; margin:16px 0; }
    strong { color:#ede5d0; font-weight:400; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="logo">AM <em>People</em></div>
    ${content}
    <hr class="divider">
    <div class="footer">© 2025 AM People · All rights reserved</div>
  </div>
</body>
</html>`;
}

// ── Application confirmation ──────────────────────────────
async function sendApplicationConfirmation({ firstName, email, refNum }) {
  const html = baseTemplate(`
    <h1>Application<br><em>received.</em></h1>
    <p>Thank you, ${firstName}. We have received your application to join AM People.</p>
    <p>Our membership committee reviews every application personally. You will hear from us within <strong>5–7 days</strong>.</p>
    <div class="badge">${refNum}</div>
    <p>Keep this reference number safe — you can use it to check your application status.</p>
  `);

  await transporter.sendMail({
    from: `AM People <${FROM}>`,
    to: email,
    subject: `Your AM People application — ${refNum}`,
    html,
  });
}

// ── Application approved ──────────────────────────────────
async function sendApplicationApproved({ firstName, email, memberNumber, pin }) {
  const html = baseTemplate(`
    <h1>Welcome to<br><em>AM People.</em></h1>
    <p>${firstName}, your application has been approved. You are now a member.</p>
    <div class="badge">${memberNumber}</div>
    <p>Your member number is <strong>${memberNumber}</strong> and your temporary PIN is <strong>${pin}</strong>.</p>
    <p>Please change your PIN after your first login.</p>
    <p>Your world is ready.</p>
  `);

  await transporter.sendMail({
    from: `AM People <${FROM}>`,
    to: email,
    subject: `Welcome to AM People — ${memberNumber}`,
    html,
  });
}

// ── RSVP confirmation ─────────────────────────────────────
async function sendRsvpConfirmation({ firstName, email, eventName, eventDate, venue, city }) {
  const html = baseTemplate(`
    <h1>You are<br><em>confirmed.</em></h1>
    <p>${firstName}, your RSVP for <strong>${eventName}</strong> is confirmed.</p>
    <p><strong>${new Date(eventDate).toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' })}</strong><br>
    ${venue}, ${city}</p>
    <p>We look forward to seeing you there.</p>
  `);

  await transporter.sendMail({
    from: `AM People <${FROM}>`,
    to: email,
    subject: `RSVP confirmed — ${eventName}`,
    html,
  });
}

module.exports = {
  sendApplicationConfirmation,
  sendApplicationApproved,
  sendRsvpConfirmation,
};
