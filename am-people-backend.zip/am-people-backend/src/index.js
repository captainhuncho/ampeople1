// src/index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Security headers ─────────────────────────────────────
app.use(helmet());

// ── CORS ─────────────────────────────────────────────────
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:8080',
    'http://localhost:3000',
    'http://localhost:8080',
  ],
  credentials: true,
}));

// ── Raw body for Stripe webhooks (must come before json) ──
app.use('/billing/webhook', express.raw({ type: 'application/json' }), (req, res, next) => {
  req.rawBody = req.body;
  next();
});

// ── Body parsing ─────────────────────────────────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));

// ── Global rate limit ────────────────────────────────────
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
}));

// ── Health check ─────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'AM People API', ts: new Date().toISOString() });
});

// ── Routes ───────────────────────────────────────────────
app.use('/auth',         require('./routes/auth'));
app.use('/members',      require('./routes/members'));
app.use('/events',       require('./routes/events'));
app.use('/applications', require('./routes/applications'));
app.use('/billing',      require('./routes/billing'));
app.use('/wallet',       require('./routes/wallet'));

// ── 404 ──────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Error handler ────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  });
});

// ── Start ────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
  ✦ AM People API
  ─────────────────────────
  Port:     ${PORT}
  Env:      ${process.env.NODE_ENV || 'development'}
  DB:       ${process.env.DATABASE_URL ? '✓ Connected' : '✗ Not configured'}
  Stripe:   ${process.env.STRIPE_SECRET_KEY ? '✓ Configured' : '✗ Not configured'}
  `);
});

module.exports = app;
