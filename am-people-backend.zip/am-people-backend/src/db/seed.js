// src/db/seed.js
// Run with: npm run db:seed

require('dotenv').config();
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function seed() {
  const client = await pool.connect();
  try {
    console.log('🌱 Seeding database...');

    // ── Founding member: Maxwell Adjavon ──────────────────
    const pinHash = await bcrypt.hash('0001', 12);
    const memberId = uuidv4();

    await client.query(`
      INSERT INTO members (
        id, member_number, first_name, last_name, email,
        phone, home_city, profession, tier_id, pin_hash,
        is_founding, profile_handle
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      ON CONFLICT (member_number) DO NOTHING
    `, [
      memberId, 'AM-00001', 'Maxwell', 'Adjavon',
      'maxwell@ampeople.co', '+233200000001', 'Accra',
      'Founder, AM People', 4, pinHash, true, 'maxwelladjavon'
    ]);

    // ── Sample events ─────────────────────────────────────
    const events = [
      { slug:'rooftop-sundowner-mar', name:'Rooftop Sundowner', date:'2025-03-08', time:'18:30', city:'Accra', venue:'Skybar 57', capacity:60, tier:1, status:'open', dress:'Smart casual', emoji:'🌅', desc:'An open-air evening on one of Accra\u2019s finest rooftops.' },
      { slug:'art-basel-dinner-mar', name:'Art Basel Dinner', date:'2025-03-12', time:'20:00', city:'Basel', venue:'Private Residence', capacity:18, tier:3, status:'invite_only', dress:'Evening wear', emoji:'🎨', desc:'An intimate dinner hosted alongside Art Basel.' },
      { slug:'private-dinner-lagos-mar', name:'Private Dinner \u2014 Lagos', date:'2025-03-14', time:'20:00', city:'Lagos', venue:'The Terrace', capacity:24, tier:2, status:'open', dress:'Smart casual', emoji:'🕯️', desc:'A curated dinner for Select and above members.' },
      { slug:'music-minds-london-mar', name:'Music & Minds Session', date:'2025-03-19', time:'19:00', city:'London', venue:'The Vaults', capacity:80, tier:1, status:'open', dress:'Casual', emoji:'🎵', desc:'A listening session and panel on African creative identity.' },
      { slug:'wellness-retreat-nairobi-mar', name:'Wellness Retreat Weekend', date:'2025-03-22', time:'09:00', city:'Nairobi', venue:'Ngong Hills Estate', capacity:20, tier:2, status:'open', dress:'Comfortable', emoji:'🌿', desc:'Three days of intentional rest in the Ngong Hills.' },
      { slug:'founding-members-gala-mar', name:'Founding Members Gala', date:'2025-03-28', time:'21:00', city:'Accra', venue:'The Grand Hall', capacity:247, tier:4, status:'invite_only', dress:'Black tie', emoji:'✦', desc:'Our annual celebration for Founding Members.', founding_only:true },
    ];

    for (const ev of events) {
      await client.query(`
        INSERT INTO events (slug, name, description, event_date, event_time, city, venue, capacity, min_tier_id, status, dress_code, emoji, is_founding_only)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
        ON CONFLICT (slug) DO NOTHING
      `, [ev.slug, ev.name, ev.desc, ev.date, ev.time, ev.city, ev.venue, ev.capacity, ev.tier, ev.status, ev.dress, ev.emoji, ev.founding_only || false]);
    }

    console.log('✅ Seed complete — Maxwell Adjavon (AM-00001) PIN: 0001');
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
