// src/db/migrate.js
// Run with: npm run db:migrate

require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const migrations = `

-- ── EXTENSIONS ──────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── TIERS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tiers (
  id          SERIAL PRIMARY KEY,
  slug        VARCHAR(20) UNIQUE NOT NULL,  -- 'core' | 'select' | 'elite' | 'founding'
  name        VARCHAR(50) NOT NULL,
  level       INTEGER NOT NULL,             -- 1=core, 2=select, 3=elite, 4=founding
  is_awarded  BOOLEAN DEFAULT FALSE,        -- founding is awarded, not purchased
  stripe_price_id VARCHAR(100),
  annual_fee  NUMERIC(10,2),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO tiers (slug, name, level, is_awarded, annual_fee) VALUES
  ('core',     'Core',    1, FALSE, 1200.00),
  ('select',   'Select',  2, FALSE, 3600.00),
  ('elite',    'Elite',   3, FALSE, 9600.00),
  ('founding', 'Founding',4, TRUE,  NULL)
ON CONFLICT (slug) DO NOTHING;

-- ── MEMBERS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS members (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  member_number   VARCHAR(10) UNIQUE NOT NULL,  -- AM-00001
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  email           VARCHAR(255) UNIQUE NOT NULL,
  phone           VARCHAR(30),
  home_city       VARCHAR(100),
  profession      VARCHAR(150),
  tier_id         INTEGER REFERENCES tiers(id) DEFAULT 1,
  pin_hash        VARCHAR(255) NOT NULL,
  is_active       BOOLEAN DEFAULT TRUE,
  is_founding     BOOLEAN DEFAULT FALSE,
  joined_at       TIMESTAMPTZ DEFAULT NOW(),
  last_login      TIMESTAMPTZ,
  profile_handle  VARCHAR(100) UNIQUE,
  avatar_url      VARCHAR(500),
  stripe_customer_id VARCHAR(100),
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── MEMBER SESSIONS ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS member_sessions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  member_id   UUID REFERENCES members(id) ON DELETE CASCADE,
  token_hash  VARCHAR(255) NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  ip_address  VARCHAR(45),
  user_agent  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── MEMBERSHIP APPLICATIONS ─────────────────────────────
CREATE TABLE IF NOT EXISTS applications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ref_number      VARCHAR(20) UNIQUE NOT NULL,  -- AM-APP-1234
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100) NOT NULL,
  email           VARCHAR(255) NOT NULL,
  phone           VARCHAR(30),
  home_city       VARCHAR(100),
  profession      VARCHAR(150),
  source          VARCHAR(100),      -- how they heard about AM People
  referring_member_number VARCHAR(10),
  why_join        TEXT,
  preferred_tier  VARCHAR(20),
  status          VARCHAR(20) DEFAULT 'pending',
                  -- pending | reviewing | approved | rejected | waitlisted
  reviewed_by     UUID,              -- admin member id
  reviewed_at     TIMESTAMPTZ,
  rejection_reason TEXT,
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── EVENTS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS events (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug            VARCHAR(150) UNIQUE NOT NULL,
  name            VARCHAR(200) NOT NULL,
  description     TEXT,
  event_date      DATE NOT NULL,
  event_time      VARCHAR(20),
  city            VARCHAR(100),
  venue           VARCHAR(200),
  capacity        INTEGER,
  min_tier_id     INTEGER REFERENCES tiers(id) DEFAULT 1,
  status          VARCHAR(20) DEFAULT 'open',
                  -- open | invite_only | cancelled | completed
  dress_code      VARCHAR(100),
  emoji           VARCHAR(10),
  is_founding_only BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── EVENT RSVPs ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rsvps (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_id    UUID REFERENCES events(id) ON DELETE CASCADE,
  member_id   UUID REFERENCES members(id) ON DELETE CASCADE,
  status      VARCHAR(20) DEFAULT 'confirmed',
              -- confirmed | cancelled | waitlisted | attended
  rsvp_at     TIMESTAMPTZ DEFAULT NOW(),
  cancelled_at TIMESTAMPTZ,
  notes       TEXT,
  UNIQUE(event_id, member_id)
);

-- ── BILLING / SUBSCRIPTIONS ─────────────────────────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  member_id               UUID REFERENCES members(id) ON DELETE CASCADE,
  stripe_subscription_id  VARCHAR(100) UNIQUE,
  stripe_customer_id      VARCHAR(100),
  tier_id                 INTEGER REFERENCES tiers(id),
  status                  VARCHAR(30) DEFAULT 'active',
                          -- active | cancelled | past_due | unpaid | trialing
  current_period_start    TIMESTAMPTZ,
  current_period_end      TIMESTAMPTZ,
  cancel_at_period_end    BOOLEAN DEFAULT FALSE,
  cancelled_at            TIMESTAMPTZ,
  created_at              TIMESTAMPTZ DEFAULT NOW(),
  updated_at              TIMESTAMPTZ DEFAULT NOW()
);

-- ── WALLET PASSES ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wallet_passes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  member_id       UUID REFERENCES members(id) ON DELETE CASCADE,
  platform        VARCHAR(10) NOT NULL,  -- 'apple' | 'google'
  pass_serial     VARCHAR(100) UNIQUE,
  auth_token      VARCHAR(255),
  last_updated    TIMESTAMPTZ DEFAULT NOW(),
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES ─────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_members_email         ON members(email);
CREATE INDEX IF NOT EXISTS idx_members_member_number ON members(member_number);
CREATE INDEX IF NOT EXISTS idx_rsvps_member          ON rsvps(member_id);
CREATE INDEX IF NOT EXISTS idx_rsvps_event           ON rsvps(event_id);
CREATE INDEX IF NOT EXISTS idx_applications_email    ON applications(email);
CREATE INDEX IF NOT EXISTS idx_sessions_member       ON member_sessions(member_id);
CREATE INDEX IF NOT EXISTS idx_events_date           ON events(event_date);

-- ── UPDATED_AT TRIGGER ───────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DO $$ DECLARE t TEXT;
BEGIN FOR t IN SELECT unnest(ARRAY['members','applications','events','subscriptions'])
LOOP EXECUTE format('DROP TRIGGER IF EXISTS trg_%I_updated ON %I', t, t);
     EXECUTE format('CREATE TRIGGER trg_%I_updated BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at()', t, t);
END LOOP; END $$;

`;

async function migrate() {
  const client = await pool.connect();
  try {
    console.log('🔄 Running migrations...');
    await client.query(migrations);
    console.log('✅ Migrations complete');
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

migrate();
